from flask import Flask, request, render_template

app = Flask(__name__)

# 设置一个文件来保存数据
DATA_FILE = 'data.txt'

@app.route('/', methods=['GET', 'POST'])
def execute():
    if request.method == 'POST':
        # 从 POST 请求中读取数据并保存到文件
        with open(DATA_FILE, 'w') as file:
            file.write(request.get_data(as_text=True))

    # 从文件中读取数据
    data = ''
    try:
        with open(DATA_FILE, 'r') as file:
            data = file.read()
    except FileNotFoundError:
        # 如果文件不存在，则忽略错误
        pass

    # 打印接收到的数据到控制台
    print("Received data:", data)
    res = "结果为：" + data

    # 返回一个包含接收到的数据的 HTML 页面
    return render_template('result.html', received_data=res)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8881)
